public class H extends null {

    double ad();

    int cc();
}
