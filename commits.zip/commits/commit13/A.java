public class A extends null {

    Object rr();

    void aa();
}
