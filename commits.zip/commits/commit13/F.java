public class F extends null {

    int hh();

    String kk();
}
