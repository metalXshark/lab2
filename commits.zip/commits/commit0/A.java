public interface A {

    Object rr();

    void aa();
}
