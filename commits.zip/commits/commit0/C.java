public interface C {

    double ee();

    void bb();
}
