public interface H {

    double ad();

    int cc();
}
