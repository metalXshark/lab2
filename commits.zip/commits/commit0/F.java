public interface F {

    int hh();

    String kk();
}
